/*var express = require("express");
var app = express();
var mongoose = require("mongoose");
mongoose.Promise = global.Promise;
var bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://@localhost:27017/ocs;
var nameSchema = new mongoose.Schema({
    firstName: String,
    lastName: String
});
var User = mongoose.model("User", nameSchema);

app.post("/sendLoginData", (req, res) => {
    var myData = new User(req.body);
    console.log(myData);
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("ocs");
        dbo.createCollection("test", function(err, res){
            if (err) throw err;

            db.close();
        });
        dbo.collection("test").insertOne(myData, function(err, res) {
            if (err) throw err;
            console.log("Feedback sent to database");
            db.close();
        });
    });
});
module.exports = router;*/


var fs = require('fs');
var http = require('http');
var url = require('url');
var ROOT_DIR = "static/";
var MongoClient = require('mongodb').MongoClient;
var db,menu;
var dbURL="mongodb://@localhost:27017/ocs"
var server=http.createServer(function (req, res) {
   var urlObj = url.parse(req.url, true, false);
  console.log(urlObj.pathname)
  if(req.method=="GET")
    if(urlObj.pathname=="/menu"){
      var query={}
      findMenuItems(res,query)
    }
  else{ 
  fs.readFile(ROOT_DIR + urlObj.pathname, function (err,data) {
  if (err) {
    res.writeHead(404);
    res.end("<h1>Page does not exist!</h1>");
    return;
  }
  res.writeHead(200);
  res.end(data);
})
}
if(req.method="POST")
{
  //placeOrder request
  if(urlObj.pathname=="/placeOrder"){
    var dataFromClient=''
    req.on('data',function(chunk){
      dataFromClient+=chunk;
    })
    req.on('end',function(){
      insertOrders(dataFromClient,res)
      res.writeHead(200);
      res.end("Thank you for Order!")
    })
  }


}



})
// Initialize connection once
MongoClient.connect(dbURL, 
                    function(err, database) {
  if(err) throw err;

  db=database.db("ocs")
  
  // Start the application after the database connection is ready
  server.listen(8000);
  console.log("Listening on port 8000");
});







function sendLoginData(logindata){
    //MongoClient.connect(url, function(err, db) 
    {
        if (err) throw err;
        var dbo = db.db("ocs");
        dbo.collection("login").insertOne(feedback, function(err, res) {
            if (err) throw err;
            console.log("Login data sent to database");
            db.close();
        });
    });
}

/*function getLoginData(){
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("ocs");
        dbo.collection("login").findOne({}, function(err, result) {
            if (err) throw err;
            console.log(result);
            db.close();
        });
    });
}*/
