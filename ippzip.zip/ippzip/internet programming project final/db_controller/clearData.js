//clearData
var express = require('express');
var router = express.Router();

var appVars=require('../server.js')
console.log("hello")
router.post("/",function(req,res){
	var p=appVars.getPublicPath()
	var db=appVars.getDb()
	db.collection("orders").remove({})
	res.sendFile(`${p}/viewOrders.html`)
})
module.exports=router;