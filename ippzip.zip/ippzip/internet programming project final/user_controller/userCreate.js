//userCreate
var express = require('express');
var router = express.Router();

var appVars=require('../server.js')

router.post("/",function(req,res){
	console.log(req.body.email)
	console.log(req.body.pwd)
	var p=appVars.getPublicPath()
	var db=appVars.getDb()
	db.collection("admin").insert({
		user:req.body.email,pwd:req.body.pwd
	})
	res.sendFile(`${p}/index.html`)
})
module.exports=router;