//userFeed
var express = require('express');
var router = express.Router();

var appVars=require('../server.js')

router.post("/",function(req,res){
	console.log(req.body.firstName)
	console.log(req.body.lastName)
	console.log(req.body.phone)
	console.log(req.body.comment)
	var p=appVars.getPublicPath()
	var db=appVars.getDb()
	db.collection("orders").insert({
		firstName:req.body.firstName,lastName:req.body.lastName,phone:req.body.phone,comment:req.body.comment
	})
	res.sendFile(`${p}/index.html`)
})
module.exports=router;