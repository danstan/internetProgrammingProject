var args=process.argv.slice(2)

var express = require('express');
var app = express();
var path=require('path')
var router= express.Router(); //so we can use the second file

var userAuth=require("./user_controller/userVerify.js")
var userCreate=require("./user_controller/userCreate.js")
var userFeed=require("./user_controller/userFeed.js")
var orderFs=require("./db_controller/dbOrders.js")
var clearData=require("./db_controller/clearData.js")
//var router = express.Router();
//userAuth=require("./user_controller/userVerify.js")

//router-> step1: require userVerify.js


var publicPath=path.resolve(__dirname, "static"	);
app.use(express.static(publicPath))

var bodyParser = require('body-parser')
app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies


var session=require('express-session')
var sess = {
  secret: 'keyboard cat',
  cookie: {}
}
app.use(session(sess))


var MongoClient = require('mongodb').MongoClient;
var db,menu;

if(args=="dev"){

var dbURL="mongodb://@localhost:27017/ocs"


MongoClient.connect(dbURL, 
					function(err, database) {
  if(err) throw err;

  db=database.db("pizzadb")
 
  // Start the application after the database connection is ready
  app.listen(8000);
  console.log("Listening on port 8000");
});
}
else{
  const PORT = process.env.PORT || 8000
  var dbURL="mongodb://DanAndEthan:ethananddan@ds113640.mlab.com:13640/heroku_1vz1b0zm"
  MongoClient.connect(dbURL, function(err, database){
    if(err) throw err;

    db=database.db("heroku_1vz1b0zm")

    app.listen(PORT);
    console.log("Listening on port "+PORT);
  })

}

app.get('/', function(req, res){
  res.sendFile(`${publicPath}/index.html`);
});

app.get('/orderForm',function (req,res) {
  if(req.session.user)
      res.sendFile(`${publicPath}/orderForm.html`)
    else
      res.sendFile(`${publicPath}/index.html`)
  
}) 

app.get('/login', function (req, res) {
    if (!req.query.username || !req.query.password) {
        res.redirect("loginPage");
    } else if(req.query.username === "username" && req.query.password === "password") {
        req.session.user = "staffMember";
        req.session.admin = true;
        res.redirect("options");
    }
    else{
        res.redirect("loginPage");
    }
});

/*app.get('/menu',function (req, res) {
	   var query={}
      findMenuItems(res,query)
})*/

app.use("/orderForm",userAuth)
//for any path starting with /adminLogin, use userAuth
// /adminLogin/about, /adminLogin/cathy

//demo orders.html, only valid user can access orders.html

//demo destroy session when get /logout

app.get("/getFeedback",function(req, res) {
    MongoClient.connect(dbURL, function(err, db) {
        if (err) throw err;
        var dbo = db.db("heroku_1vz1b0zm");
        dbo.collection("orders").find({}).toArray(function(err, result){
            if (err) throw err;
            res.send(result);
            db.close();
        });
    });
});


app.get('/showOrders',function(req,res){
var query={}
      findOrderItems(res,query)
})

app.get('/orderForm',function(req,res){
  console.log('/orderForm')
  if(req.session.user)
    res.sendFile(`${publicPath}/orderForm.html`)
  else{
    alert("Hello! I am an alert box!")
    res.sendFile(`${publicPath}/index.html`)
  }
})


app.get('/logout',function(req,res){
  req.session.destroy(function(){
    console.log('destroy the session')
    res.redirect('/')
  })
})

app.use("/clearData",clearData)

//router step2: use the router, userAuth
app.use("/sendLogin",userCreate)
app.use("/sendFeedback",userFeed)
// app.post("/login",function (req,res) {
//    body... 
//  console.log('login with post')
// })  
/*
function findMenuItems(res,query)
{
  console.log(query)
  db.collection("menu").find(query).toArray(function (err,results) {
 
    console.log(results)
    
    res.json(results)
  })

}
*/

function findOrderItems(res,query)
{

  db.collection("orders").find(query).toArray(function (err,results) {
 
    console.log(results)
    
    res.writeHead(200);
    res.end(JSON.stringify(results))
  })
}

var getDb=function(){
  return db
};

var getPublicPath=function(){
  return publicPath
};

module.exports.getDb=getDb
module.exports.getPublicPath=getPublicPath

//two functions to export db and publicPath